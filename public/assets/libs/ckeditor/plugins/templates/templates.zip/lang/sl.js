/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'sl', {
	button: 'Predloge',
	emptyListMsg: '(Ni pripravljenih predlog)',
	insertOption: 'Zamenjaj trenutno vsebino',
	options: 'Možnosti Predloge',
	selectPromptMsg: 'Izberite predlogo, ki jo želite odpreti v urejevalniku<br>(trenutna vsebina bo izgubljena):',
	title: 'Vsebinske predloge'
} );
