/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'bs', {
	button: 'Templates', // MISSING
	emptyListMsg: '(No templates defined)', // MISSING
	insertOption: 'Replace actual contents', // MISSING
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Please select the template to open in the editor', // MISSING
	title: 'Content Templates' // MISSING
} );
