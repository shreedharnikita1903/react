/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'it', {
	button: 'Modelli',
	emptyListMsg: '(Nessun modello definito)',
	insertOption: 'Cancella il contenuto corrente',
	options: 'Opzioni del Modello',
	selectPromptMsg: 'Seleziona il modello da aprire nell\'editor',
	title: 'Contenuto dei modelli'
} );
