/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'ja', {
	button: 'テンプレート',
	emptyListMsg: '(テンプレートが定義されていません)',
	insertOption: '現在のエディタの内容と置き換えます',
	options: 'テンプレートオプション',
	selectPromptMsg: 'エディターで使用するテンプレートを選択してください。<br>(現在のエディタの内容は失われます):',
	title: '内容テンプレート'
} );
